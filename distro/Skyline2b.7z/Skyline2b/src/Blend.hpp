



#ifndef Blend_HPP
#define Blend_HPP




void SetAdditiveBlender();

#endif // Blend_HPP

