


#include "Globals.hpp"

#include "Eagle.hpp"

int ww = 800;
int wh = 600;

int FPS = 60;

EagleSystem* sys = 0;
EagleGraphicsContext* win = 0;
EagleEventHandler* q = 0;
EagleTimer* t = 0;




