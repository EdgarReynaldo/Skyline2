



#ifndef Explosion_HPP
#define Explosion_HPP

#include "Eagle/Color.hpp"


void DrawExplosion(float cx , float cy , float crad , EagleColor inner_color , EagleColor outer_color);

#endif // Explosion_HPP

