

#include "City.hpp"
#include "Missiles.hpp"

class Intro {
private :
   City* city;
   Missile missile;
public :

   Intro();
   Intro() :
         city(0),
         missile
   
};

